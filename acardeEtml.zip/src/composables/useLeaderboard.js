import { ref } from 'vue'

/**
 * Petit système de classement 100% local.
 *
 * ✅ Pas besoin de Firebase
 * ✅ Les scores sont stockés en JSON dans le localStorage
 * ✅ On réutilise la même API qu'avant : useLeaderboard(gameId)
 */

const STORAGE_KEY = 'etml_arcade_leaderboard_v1'

// État global partagé entre tous les composants
const globalData = ref(loadFromStorage())

function loadFromStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return {}
    const parsed = JSON.parse(raw)
    // On s'assure que c'est bien un objet
    return parsed && typeof parsed === 'object' ? parsed : {}
  } catch (e) {
    console.error('Erreur lecture classement depuis le localStorage :', e)
    return {}
  }
}

function saveToStorage() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(globalData.value))
  } catch (e) {
    console.error('Erreur sauvegarde classement dans le localStorage :', e)
  }
}

/**
 * Permet d'utiliser le classement pour un jeu donné
 * @param {string} gameId - ex: 'morpion', 'connect4', 'snake', etc.
 */
export function useLeaderboard(gameId) {
  const scores = ref([])
  const loading = ref(false)
  const error = ref(null)
  const currentUser = ref(localStorage.getItem('playerPseudo') || '')

  const fetchScores = () => {
    loading.value = true
    try {
      const all = Array.isArray(globalData.value[gameId])
        ? globalData.value[gameId]
        : []
      // On clone pour éviter les mutations bizarres
      scores.value = [...all]
      error.value = null
    } catch (e) {
      console.error('Erreur lors du chargement du classement :', e)
      error.value = 'Impossible de charger le classement.'
    } finally {
      loading.value = false
    }

    // Pour compatibilité avec l’ancienne version (Firebase onSnapshot)
    // on renvoie une fonction "unsubscribe" vide.
    return () => {}
  }

  const addScore = async (pseudo, score, extraData = {}) => {
    try {
      const safePseudo = (pseudo || currentUser.value || 'Anonyme').trim()
      const numericScore =
        typeof score === 'number' ? score : parseFloat(score) || 0

      const newEntry = {
        pseudo: safePseudo || 'Anonyme',
        score: numericScore,
        timestamp: Date.now(),
        ...extraData,
      }

      const existing = Array.isArray(globalData.value[gameId])
        ? globalData.value[gameId]
        : []

      const updated = [...existing, newEntry]

      // On met à jour l'état global
      globalData.value = {
        ...globalData.value,
        [gameId]: updated,
      }

      // Persistance
      saveToStorage()

      // Et l'état local du composable
      scores.value = [...updated]
      error.value = null

      return true
    } catch (e) {
      console.error('Erreur lors de la sauvegarde du score :', e)
      error.value = 'Erreur lors de la sauvegarde.'
      return false
    }
  }

  // Chargement initial des scores pour ce jeu
  fetchScores()

  return {
    scores,
    loading,
    error,
    fetchScores,
    addScore,
    currentUser,
  }
}

/**
 * Optionnel : permettrait d'effacer un classement complet
 * (non utilisé pour l'instant, mais pratique pour debug)
 */
export function resetLeaderboard(gameId) {
  if (!gameId) return
  globalData.value = {
    ...globalData.value,
    [gameId]: [],
  }
  saveToStorage()
}
