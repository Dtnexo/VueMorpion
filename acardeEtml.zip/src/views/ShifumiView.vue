<script setup>
import { ref } from 'vue'

const choices = [
  { name: 'Pierre', emoji: '✊', beats: 'Ciseaux' },
  { name: 'Feuille', emoji: '✋', beats: 'Pierre' },
  { name: 'Ciseaux', emoji: '✌️', beats: 'Feuille' },
]

const playerChoice = ref(null)
const computerChoice = ref(null)
const result = ref(null) // 'win', 'lose', 'draw'
const score = ref({ player: 0, computer: 0 })

const play = (choice) => {
  playerChoice.value = choice
  const random = choices[Math.floor(Math.random() * choices.length)]
  computerChoice.value = random

  if (choice.name === random.name) {
    result.value = 'draw'
  } else if (choice.beats === random.name) {
    result.value = 'win'
    score.value.player++
  } else {
    result.value = 'lose'
    score.value.computer++
  }
}

const reset = () => {
  playerChoice.value = null
  computerChoice.value = null
  result.value = null
}
</script>

<template>
  <div class="game-wrapper">
    <div class="scoreboard">
      <div class="score-box">
        <span>Vous</span>
        <strong>{{ score.player }}</strong>
      </div>
      <div class="vs">VS</div>
      <div class="score-box">
        <span>Ordi</span>
        <strong>{{ score.computer }}</strong>
      </div>
    </div>

    <div class="game-area">
      <div v-if="!playerChoice" class="choices-container">
        <h2>Faites votre choix</h2>
        <div class="buttons">
          <button
            v-for="choice in choices"
            :key="choice.name"
            @click="play(choice)"
            class="choice-card"
          >
            <span class="emoji">{{ choice.emoji }}</span>
            <span class="name">{{ choice.name }}</span>
          </button>
        </div>
      </div>

      <div v-else class="result-container">
        <div class="battle">
          <div class="fighter winner-anim" :class="{ win: result === 'win' }">
            <span>Vous</span>
            <div class="big-emoji">{{ playerChoice.emoji }}</div>
          </div>
          <div class="fighter" :class="{ win: result === 'lose' }">
            <span>Ordi</span>
            <div class="big-emoji">{{ computerChoice.emoji }}</div>
          </div>
        </div>

        <div class="message">
          <h2 v-if="result === 'draw'" style="color: #f6bd60">Égalité !</h2>
          <h2 v-else-if="result === 'win'" style="color: #2a9d8f">Gagné ! 🎉</h2>
          <h2 v-else style="color: #e63946">Perdu... 🤖</h2>
          <button @click="reset" class="btn">Rejouer</button>
        </div>
      </div>
    </div>

    <RouterLink to="/" class="back-link">Quitter</RouterLink>
  </div>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap');

.game-wrapper {
  text-align: center;
  max-width: 600px;
  width: 100%;
  margin: 0 auto;
  font-family: 'Poppins', sans-serif;
  padding: 20px;
  color: #334155;
}

.scoreboard {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 30px;
  margin-bottom: 2rem;
  background: white;
  padding: 20px 40px;
  border-radius: 24px;
  box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.1);
}

.score-box {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 80px;
}
.score-box span {
  font-size: 0.9rem;
  color: #64748b;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 5px;
}
.score-box strong {
  font-size: 2.5rem;
  color: #0f172a;
  line-height: 1;
}

.vs {
  font-weight: 800;
  color: #cbd5e1;
  font-size: 1.2rem;
}

.choices-container h2 {
  color: #334155;
  margin-bottom: 30px;
  font-weight: 800;
}

.choices-container .buttons {
  display: flex;
  justify-content: center;
  gap: 20px;
  flex-wrap: wrap;
}

.choice-card {
  background: white;
  border: 2px solid #e2e8f0;
  border-radius: 20px;
  padding: 25px;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  width: 120px;
  display: flex;
  flex-direction: column;
  align-items: center;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
}

.choice-card:hover {
  transform: translateY(-8px);
  border-color: #3b82f6;
  box-shadow: 0 20px 25px -5px rgba(59, 130, 246, 0.15);
}
.choice-card:active {
  transform: translateY(-2px);
}

.choice-card .emoji {
  font-size: 3.5rem;
  margin-bottom: 10px;
  transition: transform 0.2s;
}
.choice-card:hover .emoji {
  transform: scale(1.1);
}

.choice-card .name {
  font-weight: 700;
  color: #64748b;
  font-size: 1rem;
}
.choice-card:hover .name {
  color: #3b82f6;
}

.battle {
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-bottom: 30px;
  align-items: stretch;
}

.fighter {
  padding: 30px;
  background: white;
  border-radius: 24px;
  min-width: 140px;
  border: 3px solid transparent;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  align-items: center;
  transition: all 0.3s;
}

.fighter span {
  font-weight: 600;
  color: #94a3b8;
  margin-bottom: 15px;
  text-transform: uppercase;
  font-size: 0.9rem;
}

.fighter.win {
  border-color: #10b981;
  background: #ecfdf5;
  box-shadow: 0 20px 25px -5px rgba(16, 185, 129, 0.15);
  transform: scale(1.05);
  z-index: 1;
}

.big-emoji {
  font-size: 5rem;
  animation: pop 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.message h2 {
  font-size: 2.5rem;
  margin: 10px 0 25px;
  font-weight: 800;
  animation: slide-up 0.4s;
}

.btn {
  background: #0f172a;
  color: white;
  border: none;
  padding: 15px 40px;
  border-radius: 16px;
  cursor: pointer;
  font-weight: 700;
  font-size: 1.1rem;
  font-family: inherit;
  transition: all 0.2s;
  box-shadow: 0 10px 15px -3px rgba(15, 23, 42, 0.3);
}
.btn:hover {
  background: #1e293b;
  transform: translateY(-2px);
  box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.4);
}
.btn:active {
  transform: translateY(0);
}

.back-link {
  display: inline-block;
  margin-top: 40px;
  color: #94a3b8;
  text-decoration: none;
  font-weight: 600;
  transition: color 0.2s;
}
.back-link:hover {
  color: #3b82f6;
}

@keyframes pop {
  0% {
    transform: scale(0.5);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}

@keyframes slide-up {
  from {
    transform: translateY(20px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}
</style>
