<script setup>
import { ref, reactive, onMounted } from 'vue'

// Liste de mots (Thème : École/Tech/Général) - Mots de 4 à 6 lettres
const wordList = [
  'ECOLE',
  'CODEUR',
  'STAGE',
  'SOURIS',
  'ECRAN',
  'ROBOT',
  'PROJET',
  'LIVRE',
  'MATHS',
  'SPORT',
  'PAUSE',
  'CLASSE',
  'COURS',
  'EXAMEN',
  'CAHIER',
  'STYLO',
  'TABLE',
  'CHAISE',
  'ELEVE',
  'ORDI',
  'VIDEO',
  'GAMER',
  'PIXEL',
  'DATA',
  'WIFI',
]

const targetWord = ref('')
const currentGuess = ref('')
const guesses = ref([]) // Tableau des essais passés
const maxAttempts = 6
const gameState = ref('playing') // playing, won, lost
const message = ref('')

const initGame = () => {
  // Choisir un mot au hasard
  const random = wordList[Math.floor(Math.random() * wordList.length)]
  targetWord.value = random
  currentGuess.value = ''
  guesses.value = []
  gameState.value = 'playing'
  message.value = `Devinez le mot de ${random.length} lettres`
}

const submitGuess = () => {
  if (gameState.value !== 'playing') return

  const guess = currentGuess.value.toUpperCase()

  // Validation
  if (guess.length !== targetWord.value.length) {
    message.value = `Il faut ${targetWord.value.length} lettres !`
    return
  }

  // Analyse du mot (Vert/Jaune/Gris)
  const result = []
  const targetArr = targetWord.value.split('')
  const guessArr = guess.split('')

  // 1. Vérifier les lettres bien placées (VERT)
  guessArr.forEach((char, i) => {
    if (char === targetArr[i]) {
      result[i] = { char, status: 'correct' }
      targetArr[i] = null // Marquer comme utilisé
    } else {
      result[i] = { char, status: 'pending' } // Temporaire
    }
  })

  // 2. Vérifier les lettres mal placées (JAUNE)
  guessArr.forEach((char, i) => {
    if (result[i].status === 'pending') {
      const foundIndex = targetArr.indexOf(char)
      if (foundIndex !== -1) {
        result[i].status = 'present'
        targetArr[foundIndex] = null
      } else {
        result[i].status = 'absent'
      }
    }
  })

  guesses.value.push(result)
  currentGuess.value = ''

  // Vérification Victoire/Défaite
  if (guess === targetWord.value) {
    gameState.value = 'won'
    message.value = 'BRAVO ! 🎉'
  } else if (guesses.value.length >= maxAttempts) {
    gameState.value = 'lost'
    message.value = `Perdu... Le mot était ${targetWord.value}`
  }
}

onMounted(initGame)
</script>

<template>
  <div class="motus-container">
    <h1>🔡 Mot Mystère</h1>
    <div class="info-bar">
      <span class="subtitle">Vert = Bien placé | Jaune = Bonne lettre</span>
      <span class="attempts-badge" :class="{ warning: maxAttempts - guesses.length <= 2 }">
        Essais restants : {{ maxAttempts - guesses.length }}
      </span>
    </div>

    <div class="game-area">
      <!-- Grille des essais précédents -->
      <div class="grid">
        <div v-for="(attempt, i) in guesses" :key="i" class="row">
          <div v-for="(letterObj, j) in attempt" :key="j" class="tile" :class="letterObj.status">
            {{ letterObj.char }}
          </div>
        </div>

        <!-- Ligne actuelle (saisie en cours) -->
        <div v-if="gameState === 'playing'" class="row current">
          <div v-for="k in targetWord.length" :key="k" class="tile empty">
            {{ currentGuess[k - 1] || '' }}
          </div>
        </div>
      </div>

      <div class="controls" v-if="gameState === 'playing'">
        <input
          v-model="currentGuess"
          type="text"
          :maxlength="targetWord.length"
          @keyup.enter="submitGuess"
          autofocus
          placeholder="Tapez ici..."
        />
        <button @click="submitGuess" class="btn">Valider</button>
      </div>

      <div v-else class="end-screen">
        <h2>{{ message }}</h2>
        <button @click="initGame" class="btn restart">Rejouer</button>
      </div>
    </div>

    <RouterLink to="/" class="back-link">Retour Menu</RouterLink>
  </div>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap');

.motus-container {
  text-align: center;
  max-width: 500px;
  width: 100%;
  margin: 0 auto;
  font-family: 'Poppins', sans-serif;
  padding: 20px;
  background: #f8fafc;
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
}

h1 {
  color: #005596;
  font-weight: 800;
  margin-bottom: 10px;
}

.info-bar {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  margin-bottom: 30px;
}

.subtitle {
  color: #64748b;
  font-size: 0.9rem;
  font-weight: 500;
}

.attempts-badge {
  background: #e2e8f0;
  color: #475569;
  padding: 5px 15px;
  border-radius: 20px;
  font-weight: 600;
  font-size: 0.9rem;
  transition: all 0.3s;
}

.attempts-badge.warning {
  background: #fee2e2;
  color: #ef4444;
  animation: pulse 1s infinite;
}

.game-area {
  background: white;
  padding: 20px;
  border-radius: 15px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.grid {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 25px;
  align-items: center;
}

.row {
  display: flex;
  justify-content: center;
  gap: 8px;
}

.tile {
  width: 55px;
  height: 55px;
  border: 2px solid #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.8rem;
  font-weight: 700;
  text-transform: uppercase;
  background: white;
  border-radius: 8px;
  color: #1e293b;
  transition: all 0.2s;
}

/* Couleurs du jeu */
.tile.correct {
  background-color: #2a9d8f;
  color: white;
  border-color: #2a9d8f;
  box-shadow: 0 4px 0 #21867a;
}
.tile.present {
  background-color: #e9c46a;
  color: white;
  border-color: #e9c46a;
  box-shadow: 0 4px 0 #d4b15b;
}
.tile.absent {
  background-color: #94a3b8;
  color: white;
  border-color: #94a3b8;
  box-shadow: 0 4px 0 #64748b;
}
.tile.empty {
  border-color: #cbd5e1;
  background: #f1f5f9;
}

.controls {
  display: flex;
  gap: 10px;
  justify-content: center;
  margin-top: 20px;
}

input {
  padding: 12px;
  font-size: 1.2rem;
  width: 180px;
  text-transform: uppercase;
  text-align: center;
  border: 2px solid #e2e8f0;
  border-radius: 10px;
  font-family: 'Poppins', sans-serif;
  font-weight: 600;
  color: #334155;
  outline: none;
  transition: border-color 0.2s;
}

input:focus {
  border-color: #005596;
  box-shadow: 0 0 0 3px rgba(0, 85, 150, 0.1);
}

.btn {
  background: #005596;
  color: white;
  border: none;
  padding: 0 25px;
  border-radius: 10px;
  cursor: pointer;
  font-weight: 600;
  font-family: 'Poppins', sans-serif;
  transition:
    transform 0.1s,
    background 0.2s;
  box-shadow: 0 4px 0 #003d6b;
}

.btn:active {
  transform: translateY(2px);
  box-shadow: 0 2px 0 #003d6b;
}

.btn:hover {
  background: #00447a;
}

.end-screen {
  margin-top: 20px;
  animation: pop 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.end-screen h2 {
  color: #1e293b;
  margin-bottom: 15px;
}

.btn.restart {
  background: #2a9d8f;
  padding: 12px 30px;
  box-shadow: 0 4px 0 #21867a;
}
.btn.restart:hover {
  background: #21867a;
}
.btn.restart:active {
  box-shadow: 0 2px 0 #21867a;
}

@keyframes pop {
  0% {
    transform: scale(0.8);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}

@keyframes pulse {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.05);
  }
  100% {
    transform: scale(1);
  }
}

.back-link {
  display: inline-block;
  margin-top: 30px;
  color: #64748b;
  text-decoration: none;
  font-weight: 600;
  transition: color 0.2s;
}
.back-link:hover {
  color: #005596;
}
</style>
