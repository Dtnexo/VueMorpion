<script setup>
import { ref } from 'vue'

const targetNumber = ref(Math.floor(Math.random() * 100) + 1)
const userGuess = ref('')
const message = ref('Devinez le nombre entre 1 et 100')
const hint = ref('')
const attempts = ref(0)
const history = ref([])
const won = ref(false)

const checkGuess = () => {
  const guess = parseInt(userGuess.value)
  if (!guess) return

  attempts.value++
  const diff = Math.abs(targetNumber.value - guess)
  let tempHint = ''

  if (guess === targetNumber.value) {
    message.value = `Bravo ! Trouvé en ${attempts.value} coups.`
    hint.value = '🎉'
    won.value = true
    history.value.unshift({ val: guess, res: 'Gagné 🏆', class: 'win' })
  } else {
    // Direction
    if (guess < targetNumber.value) {
      message.value = "C'est plus grand 📈"
    } else {
      message.value = "C'est plus petit 📉"
    }

    // Proximité (Hot/Cold)
    if (diff <= 5) {
      tempHint = 'Brûlant ! 🔥'
    } else if (diff <= 10) {
      tempHint = 'Chaud ! 🥵'
    } else if (diff <= 20) {
      tempHint = 'Tiède 😐'
    } else {
      tempHint = 'Froid ❄️'
    }
    hint.value = tempHint

    history.value.unshift({
      val: guess,
      res: message.value,
      hint: tempHint,
      class: diff <= 5 ? 'hot' : diff <= 10 ? 'warm' : diff <= 20 ? 'tepid' : 'cold',
    })
  }
  userGuess.value = ''
}

const restart = () => {
  targetNumber.value = Math.floor(Math.random() * 100) + 1
  userGuess.value = ''
  message.value = 'Devinez le nombre entre 1 et 100'
  hint.value = ''
  attempts.value = 0
  history.value = []
  won.value = false
}
</script>

<template>
  <div class="jp-container">
    <div class="card">
      <div class="header">
        <h1>🎯 Le Juste Prix</h1>
        <span class="range-badge">1 - 100</span>
      </div>

      <div class="game-area">
        <div class="display-area">
          <h2>{{ message }}</h2>
          <div class="hint" v-if="hint">{{ hint }}</div>
        </div>

        <div class="input-area" v-if="!won">
          <input
            v-model="userGuess"
            type="number"
            placeholder="?"
            @keyup.enter="checkGuess"
            class="guess-input"
            autofocus
          />
          <button @click="checkGuess" class="btn">Valider</button>
        </div>

        <div v-else class="win-area">
          <div class="big-number">{{ targetNumber }}</div>
          <button @click="restart" class="btn restart">Rejouer</button>
        </div>

        <div class="history" v-if="history.length > 0">
          <h3>Historique</h3>
          <ul>
            <li v-for="(h, index) in history" :key="index" :class="h.class">
              <span class="h-val">{{ h.val }}</span>
              <div class="h-info">
                <span class="h-res">{{ h.res }}</span>
                <span class="h-hint" v-if="h.hint">{{ h.hint }}</span>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <RouterLink to="/" class="back-link">Retour au menu</RouterLink>
    </div>
  </div>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap');

.jp-container {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  font-family: 'Poppins', sans-serif;
  color: #334155;
}

.card {
  background: white;
  padding: 40px;
  border-radius: 24px;
  box-shadow: 0 20px 40px -5px rgba(0, 0, 0, 0.1);
}

.header {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  margin-bottom: 30px;
}

h1 {
  color: #0f172a;
  font-weight: 800;
  font-size: 2.5rem;
  margin: 0;
}

.range-badge {
  background: #e2e8f0;
  color: #64748b;
  padding: 5px 15px;
  border-radius: 20px;
  font-weight: 600;
  font-size: 0.9rem;
}

.display-area {
  margin-bottom: 30px;
  min-height: 80px;
}
.display-area h2 {
  color: #3b82f6;
  margin-bottom: 5px;
  font-size: 1.5rem;
  font-weight: 700;
}
.hint {
  font-size: 1.2rem;
  font-weight: 800;
  color: #f59e0b;
  animation: pop 0.3s;
}

.input-area {
  display: flex;
  gap: 15px;
  justify-content: center;
  margin-bottom: 30px;
}
.guess-input {
  padding: 15px;
  font-size: 1.5rem;
  border: 2px solid #e2e8f0;
  border-radius: 16px;
  width: 100px;
  text-align: center;
  font-family: inherit;
  font-weight: 700;
  color: #334155;
  outline: none;
  transition: border-color 0.2s;
}
.guess-input:focus {
  border-color: #3b82f6;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.btn {
  background: #0f172a;
  color: white;
  border: none;
  padding: 0 30px;
  border-radius: 16px;
  cursor: pointer;
  font-weight: 700;
  font-size: 1.1rem;
  font-family: inherit;
  transition: all 0.2s;
  box-shadow: 0 10px 15px -3px rgba(15, 23, 42, 0.3);
}
.btn:hover {
  background: #1e293b;
  transform: translateY(-2px);
  box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.4);
}
.btn:active {
  transform: translateY(0);
}

.win-area {
  animation: pop 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  margin-bottom: 30px;
}
.big-number {
  font-size: 6rem;
  color: #10b981;
  font-weight: 800;
  margin-bottom: 20px;
  line-height: 1;
}
.btn.restart {
  background: #10b981;
  box-shadow: 0 10px 15px -3px rgba(16, 185, 129, 0.3);
}
.btn.restart:hover {
  background: #059669;
  box-shadow: 0 20px 25px -5px rgba(16, 185, 129, 0.4);
}

.history {
  margin-top: 30px;
  border-top: 2px solid #f1f5f9;
  padding-top: 20px;
}
.history h3 {
  font-size: 1rem;
  color: #94a3b8;
  margin-bottom: 15px;
  text-transform: uppercase;
  letter-spacing: 1px;
}
.history ul {
  list-style: none;
  padding: 0;
  max-height: 200px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.history li {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 20px;
  background: #f8fafc;
  border-radius: 12px;
  border-left: 5px solid #cbd5e1;
}

.history li.hot {
  border-left-color: #ef4444;
  background: #fef2f2;
}
.history li.warm {
  border-left-color: #f59e0b;
  background: #fffbeb;
}
.history li.tepid {
  border-left-color: #eab308;
}
.history li.cold {
  border-left-color: #3b82f6;
  background: #eff6ff;
}
.history li.win {
  border-left-color: #10b981;
  background: #ecfdf5;
}

.h-val {
  font-weight: 800;
  font-size: 1.2rem;
  color: #334155;
}
.h-info {
  text-align: right;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}
.h-res {
  font-weight: 600;
  font-size: 0.9rem;
}
.h-hint {
  font-size: 0.8rem;
  opacity: 0.8;
}

.back-link {
  display: inline-block;
  margin-top: 30px;
  color: #94a3b8;
  text-decoration: none;
  font-weight: 600;
  transition: color 0.2s;
}
.back-link:hover {
  color: #3b82f6;
}

@keyframes pop {
  0% {
    transform: scale(0.5);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}
</style>
