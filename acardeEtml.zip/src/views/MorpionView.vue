<script setup>
import { ref } from 'vue'
import { RouterLink } from 'vue-router'
import { useLeaderboard } from '../composables/useLeaderboard'

const { addScore } = useLeaderboard('morpion')

// --- ÉTAT DU JEU ---
const gameStatus = ref('config')
const board = ref(Array(9).fill(null))
// Lecture automatique du pseudo
const playerPseudo = localStorage.getItem('playerPseudo') || 'Joueur'
const difficulty = ref('medium')
const currentPlayer = ref('X')
const winner = ref(null)
const winningLine = ref([])
const aiThinking = ref(false)

const startGame = () => {
  gameStatus.value = 'playing'
  resetBoard()
}

// ... (Reste de la logique de jeu identique : makeMove, makeAiMove, checkWin, etc.) ...
// Pour gagner de la place, je garde la logique IA identique à la version précédente
const makeMove = (index) => {
  if (board.value[index] || winner.value || aiThinking.value) return
  board.value[index] = 'X'
  if (checkWin('X')) {
    endGame('X')
  } else if (!board.value.includes(null)) {
    endGame('draw')
  } else {
    currentPlayer.value = 'O'
    aiThinking.value = true
    setTimeout(makeAiMove, 500)
  }
}

const makeAiMove = () => {
  let moveIndex = -1
  if (difficulty.value === 'easy') moveIndex = getRandomMove()
  else if (difficulty.value === 'medium') moveIndex = findBestMove(false)
  else moveIndex = getMinimaxMove()

  if (moveIndex !== -1) {
    board.value[moveIndex] = 'O'
    if (checkWin('O')) endGame('O')
    else if (!board.value.includes(null)) endGame('draw')
  }
  currentPlayer.value = 'X'
  aiThinking.value = false
}

// IA Logic helpers
const getRandomMove = () => {
  const available = board.value.map((v, i) => (v === null ? i : null)).filter((v) => v !== null)
  return available[Math.floor(Math.random() * available.length)]
}
const findBestMove = (useMinimax) => {
  for (let i = 0; i < 9; i++) {
    if (!board.value[i]) {
      board.value[i] = 'O'
      if (checkWin('O')) {
        board.value[i] = null
        return i
      }
      board.value[i] = null
    }
  }
  for (let i = 0; i < 9; i++) {
    if (!board.value[i]) {
      board.value[i] = 'X'
      if (checkWin('X')) {
        board.value[i] = null
        return i
      }
      board.value[i] = null
    }
  }
  return getRandomMove()
}
const getMinimaxMove = () => {
  let bestScore = -Infinity
  let move = -1
  for (let i = 0; i < 9; i++) {
    if (board.value[i] === null) {
      board.value[i] = 'O'
      let score = minimax(board.value, 0, false)
      board.value[i] = null
      if (score > bestScore) {
        bestScore = score
        move = i
      }
    }
  }
  return move
}
const minimax = (currentBoard, depth, isMaximizing) => {
  if (checkWin('O')) return 10 - depth
  if (checkWin('X')) return -10 + depth
  if (!currentBoard.includes(null)) return 0
  if (isMaximizing) {
    let bestScore = -Infinity
    for (let i = 0; i < 9; i++) {
      if (currentBoard[i] === null) {
        currentBoard[i] = 'O'
        bestScore = Math.max(minimax(currentBoard, depth + 1, false), bestScore)
        currentBoard[i] = null
      }
    }
    return bestScore
  } else {
    let bestScore = Infinity
    for (let i = 0; i < 9; i++) {
      if (currentBoard[i] === null) {
        currentBoard[i] = 'X'
        bestScore = Math.min(minimax(currentBoard, depth + 1, true), bestScore)
        currentBoard[i] = null
      }
    }
    return bestScore
  }
}

const winPatterns = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
]
const checkWin = (player) => {
  return winPatterns.some((pattern) => {
    if (pattern.every((index) => board.value[index] === player)) {
      if (gameStatus.value === 'playing' && !aiThinking.value && currentPlayer.value === player)
        winningLine.value = pattern
      return true
    }
    return false
  })
}

const endGame = async (result) => {
  winner.value = result
  gameStatus.value = 'finished'
  if (result === 'X') {
    let points = 50
    if (difficulty.value === 'medium') points = 100
    if (difficulty.value === 'hard') points = 200
    await addScore(playerPseudo, points, { difficulty: difficulty.value })
  }
}
const resetBoard = () => {
  board.value = Array(9).fill(null)
  currentPlayer.value = 'X'
  winner.value = null
  winningLine.value = []
}
</script>

<template>
  <div class="morpion-container">
    <div class="brand-header">
      <div class="logo-text">ETML <span class="subtitle">MORPION</span></div>
    </div>

    <!-- CONFIG (Plus d'input pseudo) -->
    <transition name="fade" mode="out-in">
      <div v-if="gameStatus === 'config'" class="card config-card" key="config">
        <h1>
          Bonjour, <span class="pseudo-display">{{ playerPseudo }}</span>
        </h1>
        <p class="subtitle-config">Prêt à affronter l'IA ?</p>

        <p class="label-diff">Choisis ta difficulté :</p>
        <div class="diff-select">
          <button @click="difficulty = 'easy'" :class="{ active: difficulty === 'easy' }">
            Facile
          </button>
          <button @click="difficulty = 'medium'" :class="{ active: difficulty === 'medium' }">
            Moyen
          </button>
          <button @click="difficulty = 'hard'" :class="{ active: difficulty === 'hard' }">
            Impossible
          </button>
        </div>
        <button class="etml-btn start-btn" @click="startGame">LANCER LE MATCH</button>
      </div>

      <!-- JEU -->
      <div v-else class="card game-card" key="game">
        <div class="hud">
          <div class="player p1 active">👤 {{ playerPseudo }} (X)</div>
          <div class="vs">VS</div>
          <div class="player p2" :class="{ thinking: aiThinking }">🤖 IA (O)</div>
        </div>

        <div class="board" :class="{ 'game-over': winner }">
          <div
            v-for="(cell, i) in board"
            :key="i"
            class="cell"
            :class="{ taken: cell, winner: winningLine.includes(i) }"
            @click="makeMove(i)"
          >
            <span v-if="cell">{{ cell === 'X' ? '❌' : '⭕' }}</span>
          </div>
        </div>

        <button @click="gameStatus = 'config'" class="etml-btn secondary">Abandonner</button>

        <div v-if="winner" class="overlay">
          <div class="modal">
            <h2 v-if="winner === 'X'">🎉 Gagné !</h2>
            <h2 v-else-if="winner === 'O'">💀 Perdu...</h2>
            <h2 v-else>🤝 Égalité</h2>
            <div class="actions">
              <button @click="startGame" class="etml-btn">Rejouer</button>
            </div>
          </div>
        </div>
      </div>
    </transition>

    <RouterLink to="/games" class="back-link">Retour Menu</RouterLink>
  </div>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap');

.morpion-container {
  text-align: center;
  max-width: 100%;
  margin: 0 auto;
  font-family: 'Poppins', sans-serif;
  padding: 20px;
  color: #334155;
}

.brand-header {
  margin-bottom: 30px;
}
.logo-text {
  font-size: 2.5rem;
  font-weight: 800;
  color: #0f172a;
  letter-spacing: -1px;
}
.subtitle {
  color: #3b82f6;
  font-weight: 600;
  font-size: 1.2rem;
  display: block;
  letter-spacing: 2px;
}

.card {
  background: white;
  padding: 40px;
  border-radius: 24px;
  box-shadow: 0 20px 40px -5px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
}

/* Config Screen */
.config-card h1 {
  font-size: 1.8rem;
  margin-bottom: 10px;
  color: #1e293b;
}
.pseudo-display {
  color: #3b82f6;
}
.subtitle-config {
  color: #64748b;
  margin-bottom: 30px;
}

.label-diff {
  font-weight: 600;
  margin-bottom: 15px;
  color: #334155;
  display: block;
  text-align: left;
}

.diff-select {
  display: flex;
  gap: 15px;
  margin-bottom: 30px;
}
.diff-select button {
  flex: 1;
  padding: 15px;
  border: 2px solid #e2e8f0;
  background: #f8fafc;
  cursor: pointer;
  border-radius: 16px;
  font-weight: 600;
  font-family: inherit;
  color: #64748b;
  transition: all 0.2s;
}
.diff-select button:hover {
  border-color: #3b82f6;
  color: #3b82f6;
  background: #eff6ff;
}
.diff-select button.active {
  background: #3b82f6;
  color: white;
  border-color: #3b82f6;
  box-shadow: 0 10px 20px -5px rgba(59, 130, 246, 0.4);
  transform: translateY(-2px);
}

.etml-btn {
  width: 100%;
  padding: 16px;
  background: #0f172a;
  color: white;
  border: none;
  border-radius: 16px;
  font-weight: 700;
  cursor: pointer;
  font-size: 1.1rem;
  font-family: inherit;
  transition: all 0.2s;
  box-shadow: 0 10px 20px -5px rgba(15, 23, 42, 0.3);
}
.etml-btn:hover {
  background: #1e293b;
  transform: translateY(-2px);
  box-shadow: 0 15px 25px -5px rgba(15, 23, 42, 0.4);
}
.etml-btn:active {
  transform: translateY(0);
}

.etml-btn.secondary {
  background: transparent;
  color: #64748b;
  border: 2px solid #e2e8f0;
  box-shadow: none;
  margin-top: 20px;
}
.etml-btn.secondary:hover {
  border-color: #cbd5e1;
  color: #334155;
  background: #f1f5f9;
}

.etml-btn.outline {
  background: transparent;
  border: 2px solid #3b82f6;
  color: #3b82f6;
  box-shadow: none;
  margin-top: 10px;
}
.etml-btn.outline:hover {
  background: #eff6ff;
}

/* Game Board */
.hud {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
  padding: 15px;
  background: #f8fafc;
  border-radius: 16px;
  font-weight: 700;
}
.player {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #64748b;
  transition: all 0.3s;
}
.player.active {
  color: #3b82f6;
  transform: scale(1.05);
}
.player.thinking {
  animation: pulse 1.5s infinite;
}
.vs {
  color: #cbd5e1;
  font-size: 0.9rem;
}

.board {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 15px;
  margin: 30px 0;
}
.cell {
  background: #f1f5f9;
  height: 140px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 5rem;
  border-radius: 24px;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.05);
}
.cell:hover:not(.taken) {
  background: #e2e8f0;
  transform: translateY(-2px);
}
.cell.taken {
  background: white;
  box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.05);
  cursor: default;
}
.cell span {
  animation: pop 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.cell.winner {
  background: #dcfce7;
  color: #16a34a;
  animation: win-pulse 1s infinite;
}

/* Modal */
.overlay {
  position: absolute;
  inset: 0;
  background: rgba(15, 23, 42, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 24px;
  backdrop-filter: blur(4px);
  animation: fade-in 0.3s;
}
.modal {
  background: white;
  padding: 40px;
  border-radius: 24px;
  text-align: center;
  width: 80%;
  max-width: 350px;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  animation: slide-up 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}
.modal h2 {
  font-size: 2rem;
  margin-bottom: 25px;
  color: #1e293b;
}

.back-link {
  display: inline-block;
  margin-top: 30px;
  color: #94a3b8;
  text-decoration: none;
  font-weight: 600;
  transition: color 0.2s;
}
.back-link:hover {
  color: #3b82f6;
}

/* Animations */
@keyframes pop {
  0% {
    transform: scale(0.5);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}
@keyframes fade-in {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes slide-up {
  from {
    transform: translateY(20px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}
@keyframes win-pulse {
  0% {
    transform: scale(1);
    box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.4);
  }
  70% {
    transform: scale(1.02);
    box-shadow: 0 0 0 10px rgba(22, 163, 74, 0);
  }
  100% {
    transform: scale(1);
    box-shadow: 0 0 0 0 rgba(22, 163, 74, 0);
  }
}
@keyframes pulse {
  0% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
  100% {
    opacity: 1;
  }
}
</style>
