<script setup>
import { ref, onMounted } from 'vue'
import { RouterLink } from 'vue-router'

const icons = ['🚀', '🐱', '💀', '🍕', '🦄', '🤖', '🔥', '💎']
const cards = ref([])
const flippedCards = ref([])
const matchedPairs = ref(0)
const moves = ref(0)
const gameStarted = ref(false)
const gameWon = ref(false)

// Mélanger et initier les cartes
const initGame = () => {
  const pairs = [...icons, ...icons]
  for (let i = pairs.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[pairs[i], pairs[j]] = [pairs[j], pairs[i]]
  }

  cards.value = pairs.map((icon, index) => ({
    id: index,
    icon,
    isFlipped: false,
    isMatched: false,
  }))

  flippedCards.value = []
  matchedPairs.value = 0
  moves.value = 0
  gameStarted.value = true
  gameWon.value = false
}

const flipCard = (card) => {
  if (!gameStarted.value || card.isFlipped || card.isMatched || flippedCards.value.length >= 2)
    return

  card.isFlipped = true
  flippedCards.value.push(card)

  if (flippedCards.value.length === 2) {
    moves.value++
    checkForMatch()
  }
}

const checkForMatch = () => {
  const [card1, card2] = flippedCards.value

  if (card1.icon === card2.icon) {
    // Correspondance trouvée
    card1.isMatched = true
    card2.isMatched = true
    // IMPORTANT : On garde isFlipped à true aussi pour être sûr
    card1.isFlipped = true
    card2.isFlipped = true

    matchedPairs.value++
    flippedCards.value = [] // On vide la sélection

    if (matchedPairs.value === icons.length) {
      setTimeout(() => (gameWon.value = true), 500)
    }
  } else {
    // Pas de correspondance, on retourne après un délai
    setTimeout(() => {
      card1.isFlipped = false
      card2.isFlipped = false
      flippedCards.value = []
    }, 1000)
  }
}

onMounted(initGame)
</script>

<template>
  <div class="memory-container">
    <div class="brand-header">
      <div class="logo-text">ETML <span class="subtitle">MEMORY</span></div>
    </div>

    <div class="card game-panel">
      <!-- Stats du jeu -->
      <div class="stats-bar">
        <div class="stat-item">
          <span class="label">Coups</span>
          <span class="value">{{ moves }}</span>
        </div>
        <div class="stat-item">
          <span class="label">Paires</span>
          <span class="value">{{ matchedPairs }} / {{ icons.length }}</span>
        </div>
        <button @click="initGame" class="reset-icon-btn" title="Recommencer">🔄</button>
      </div>

      <!-- Grille de cartes -->
      <div class="grid-container">
        <div
          v-for="card in cards"
          :key="card.id"
          class="memory-card"
          :class="{ flipped: card.isFlipped || card.isMatched, matched: card.isMatched }"
          @click="flipCard(card)"
        >
          <div class="card-inner">
            <div class="card-front">?</div>
            <div class="card-back">{{ card.icon }}</div>
          </div>
        </div>
      </div>

      <!-- Écran de victoire -->
      <transition name="fade">
        <div v-if="gameWon" class="result-overlay">
          <div class="result-box">
            <h2>🎉 Bravo !</h2>
            <p>
              Tu as tout trouvé en <strong>{{ moves }}</strong> coups.
            </p>
            <div class="actions">
              <button @click="initGame" class="etml-btn">Rejouer</button>
              <RouterLink to="/" class="etml-btn secondary">Menu Principal</RouterLink>
            </div>
          </div>
        </div>
      </transition>
    </div>

    <RouterLink to="/" class="back-link">Retour au menu</RouterLink>
  </div>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800&display=swap');

.memory-container {
  text-align: center;
  max-width: 600px;
  width: 100%;
  margin: 0 auto;
  font-family: 'Poppins', sans-serif;
  padding: 20px;
  color: #334155;
}

.brand-header {
  margin-bottom: 30px;
}
.logo-text {
  font-size: 2.5rem;
  font-weight: 800;
  color: #0f172a;
  letter-spacing: -1px;
}
.subtitle {
  color: #3b82f6;
  font-weight: 600;
  font-size: 1.2rem;
  display: block;
  letter-spacing: 2px;
}

.game-panel {
  background: white;
  padding: 30px;
  border-radius: 24px;
  box-shadow: 0 20px 40px -5px rgba(0, 0, 0, 0.1);
  position: relative;
  overflow: hidden; /* Pour le flou overlay */
}

.stats-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  background: #f8fafc;
  padding: 15px 25px;
  border-radius: 16px;
  border: 1px solid #e2e8f0;
}

.stat-item {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.label {
  font-size: 0.75rem;
  color: #64748b;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}
.value {
  font-size: 1.5rem;
  font-weight: 700;
  color: #0f172a;
  line-height: 1.2;
}

.reset-icon-btn {
  background: white;
  border: 1px solid #e2e8f0;
  width: 40px;
  height: 40px;
  border-radius: 12px;
  font-size: 1.2rem;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #64748b;
}
.reset-icon-btn:hover {
  transform: rotate(180deg);
  background: #eff6ff;
  color: #3b82f6;
  border-color: #3b82f6;
}

/* Grille */
.grid-container {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 15px;
  perspective: 1000px;
}

.memory-card {
  background-color: transparent;
  aspect-ratio: 1;
  cursor: pointer;
}

.card-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
  transform-style: preserve-3d;
  border-radius: 16px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.memory-card:hover .card-inner {
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}

.memory-card.flipped .card-inner,
.memory-card.matched .card-inner {
  transform: rotateY(180deg);
}

.card-front,
.card-back {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 16px;
  font-weight: 800;
}

.card-front {
  background: #3b82f6;
  color: rgba(255, 255, 255, 0.5);
  font-size: 2rem;
  background-image: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
}

.card-back {
  background-color: white;
  color: #333;
  transform: rotateY(180deg);
  font-size: 3rem;
  border: 2px solid #e2e8f0;
}

/* Matched state */
.memory-card.matched .card-back {
  background-color: #ecfdf5;
  border-color: #10b981;
  box-shadow: inset 0 0 20px rgba(16, 185, 129, 0.1);
}

/* UI Elements */
.etml-btn {
  width: 100%;
  padding: 14px;
  background: #0f172a;
  color: white;
  border: none;
  border-radius: 12px;
  font-weight: 700;
  cursor: pointer;
  font-size: 1rem;
  font-family: inherit;
  transition: all 0.2s;
  text-decoration: none;
  display: inline-block;
}
.etml-btn:hover {
  background: #1e293b;
  transform: translateY(-2px);
}

.etml-btn.secondary {
  background: transparent;
  color: #64748b;
  border: 2px solid #e2e8f0;
  margin-top: 10px;
}
.etml-btn.secondary:hover {
  border-color: #cbd5e1;
  color: #334155;
  background: #f1f5f9;
}

.result-overlay {
  position: absolute;
  inset: 0;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(8px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10;
  border-radius: 24px;
}
.result-box {
  text-align: center;
  width: 85%;
  background: white;
  padding: 30px;
  border-radius: 24px;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  border: 1px solid #e2e8f0;
  animation: slide-up 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}
.result-box h2 {
  color: #0f172a;
  font-size: 2rem;
  margin-bottom: 10px;
  font-weight: 800;
}
.result-box p {
  color: #64748b;
  margin-bottom: 25px;
  font-size: 1.1rem;
}
.result-box strong {
  color: #3b82f6;
}
.actions {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.back-link {
  display: inline-block;
  margin-top: 30px;
  color: #94a3b8;
  text-decoration: none;
  font-weight: 600;
  transition: color 0.2s;
}
.back-link:hover {
  color: #3b82f6;
}

@keyframes slide-up {
  from {
    transform: translateY(20px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
