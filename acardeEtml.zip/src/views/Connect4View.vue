<script setup>
import { ref, computed } from 'vue'
import { RouterLink } from 'vue-router'
import { useLeaderboard } from '../composables/useLeaderboard'

const { addScore } = useLeaderboard('connect4')

// --- CONFIG ---
const ROWS = 6
const COLS = 7
const EMPTY = 0
const P1 = 1
const AI = 2

// --- ÉTAT ---
const gameStarted = ref(false)
const board = ref([])
// Récupération automatique du pseudo
const playerPseudo = localStorage.getItem('playerPseudo') || 'Joueur'
const difficulty = ref('medium')
const currentPlayer = ref(P1)
const winner = ref(null)
const winningCells = ref([])
const aiThinking = ref(false)

const startGame = () => {
  // Reset complet
  board.value = Array.from({ length: ROWS }, () => Array(COLS).fill(EMPTY))
  gameStarted.value = true
  winner.value = null
  winningCells.value = []
  currentPlayer.value = P1
  aiThinking.value = false
}

const backToSetup = () => {
  gameStarted.value = false
}

// --- JEU ---
const dropPiece = (col) => {
  // Sécurités anti-clic
  if (!gameStarted.value || winner.value || aiThinking.value || currentPlayer.value !== P1) return

  if (placeToken(col, P1)) {
    if (checkWin(P1)) {
      handleWin(P1)
    } else if (checkDraw()) {
      handleWin('draw')
    } else {
      // Tour IA
      currentPlayer.value = AI
      aiThinking.value = true
      setTimeout(aiTurn, 600)
    }
  }
}

const placeToken = (col, player) => {
  // On cherche la case vide la plus basse
  for (let r = ROWS - 1; r >= 0; r--) {
    if (board.value[r][col] === EMPTY) {
      board.value[r][col] = player
      return true
    }
  }
  return false
}

// --- IA ---
const aiTurn = () => {
  let col = -1

  if (difficulty.value === 'easy') {
    col = getRandomValidCol()
  } else {
    // Tente de gagner ou bloquer
    col = findBestCol()
  }

  // Si aucune colonne trouvée par stratégie, random
  if (col === -1) col = getRandomValidCol()

  if (col !== -1) {
    placeToken(col, AI)
    if (checkWin(AI)) handleWin(AI)
    else if (checkDraw()) handleWin('draw')
    else currentPlayer.value = P1
  }

  aiThinking.value = false
}

const getRandomValidCol = () => {
  const valids = []
  for (let c = 0; c < COLS; c++) if (board.value[0][c] === EMPTY) valids.push(c)
  if (valids.length === 0) return -1
  return valids[Math.floor(Math.random() * valids.length)]
}

const findBestCol = () => {
  // 1. Gagner immédiatement
  for (let c = 0; c < COLS; c++) {
    if (canPlay(c)) {
      placeToken(c, AI)
      if (checkWin(AI, true)) {
        undo(c)
        return c
      }
      undo(c)
    }
  }
  // 2. Bloquer le joueur
  for (let c = 0; c < COLS; c++) {
    if (canPlay(c)) {
      placeToken(c, P1)
      if (checkWin(P1, true)) {
        undo(c)
        return c
      }
      undo(c)
    }
  }
  return -1
}

const canPlay = (c) => board.value[0][c] === EMPTY
const undo = (c) => {
  for (let r = 0; r < ROWS; r++)
    if (board.value[r][c] !== EMPTY) {
      board.value[r][c] = EMPTY
      return
    }
}

// --- VICTOIRE ---
const checkWin = (p, simulate = false) => {
  // Horizontale, Verticale, Diagonales
  const dirs = [
    [0, 1],
    [1, 0],
    [1, 1],
    [1, -1],
  ]
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      if (board.value[r][c] === p) {
        for (let [dr, dc] of dirs) {
          if (
            r + 3 * dr < ROWS &&
            r + 3 * dr >= 0 &&
            c + 3 * dc < COLS &&
            c + 3 * dc >= 0 &&
            board.value[r + dr][c + dc] === p &&
            board.value[r + 2 * dr][c + 2 * dc] === p &&
            board.value[r + 3 * dr][c + 3 * dc] === p
          ) {
            if (!simulate) {
              winningCells.value = [
                [r, c],
                [r + dr, c + dc],
                [r + 2 * dr, c + 2 * dc],
                [r + 3 * dr, c + 3 * dc],
              ]
            }
            return true
          }
        }
      }
    }
  }
  return false
}

const checkDraw = () => board.value[0].every((c) => c !== EMPTY)

const handleWin = async (res) => {
  winner.value = res
  if (res === P1) {
    let pts = difficulty.value === 'hard' ? 300 : difficulty.value === 'medium' ? 150 : 50
    await addScore(playerPseudo, pts, { difficulty: difficulty.value })
  }
}

const isWinningCell = (r, c) => {
  return winningCells.value.some(([wr, wc]) => wr === r && wc === c)
}
</script>

<template>
  <div class="c4-container">
    <div class="brand-header">
      <div class="logo-text">ETML <span class="subtitle">PUISSANCE 4</span></div>
    </div>

    <transition name="fade" mode="out-in">
      <!-- SETUP -->
      <div v-if="!gameStarted" class="card setup-card" key="setup">
        <h1>Duel Arc-en-ciel</h1>
        <p class="intro-text">
          Bonjour <strong>{{ playerPseudo }}</strong>
        </p>

        <p class="label-diff">Choisis ta difficulté :</p>
        <div class="diff-select">
          <button @click="difficulty = 'easy'" :class="{ active: difficulty === 'easy' }">
            Facile
          </button>
          <button @click="difficulty = 'medium'" :class="{ active: difficulty === 'medium' }">
            Moyen
          </button>
          <button @click="difficulty = 'hard'" :class="{ active: difficulty === 'hard' }">
            Difficile
          </button>
        </div>

        <button class="etml-btn start-btn" @click="startGame">LANCER LE MATCH</button>
      </div>

      <!-- JEU -->
      <div v-else class="game-area" key="game">
        <div class="game-hud">
          <div class="player-tag p1" :class="{ active: currentPlayer === P1 }">
            <span class="dot"></span> {{ playerPseudo }}
          </div>
          <div class="game-status">{{ winner ? 'FINI' : 'VS' }}</div>
          <div class="player-tag p2" :class="{ active: currentPlayer === AI }">
            <span class="dot"></span> IA {{ aiThinking ? '...' : '' }}
          </div>
        </div>

        <div class="board-container">
          <!-- COUCHE CLIC : Z-INDEX TRÈS ÉLEVÉ POUR PASSER AU DESSUS -->
          <div class="click-layer">
            <div
              v-for="col in COLS"
              :key="col"
              class="col-trigger"
              @click="dropPiece(col - 1)"
            ></div>
          </div>

          <div class="board-visual">
            <div v-for="(row, rIndex) in board" :key="rIndex" class="row">
              <div v-for="(cell, cIndex) in row" :key="cIndex" class="cell">
                <div class="hole-mask"></div>
                <transition name="drop">
                  <div
                    v-if="cell !== EMPTY"
                    class="piece"
                    :class="{
                      'is-p1': cell === P1,
                      'is-p2': cell === AI,
                      'is-winner': isWinningCell(rIndex, cIndex),
                    }"
                    :style="{ '--row-depth': rIndex }"
                  ></div>
                </transition>
              </div>
            </div>
          </div>
        </div>

        <transition name="pop">
          <div v-if="winner" class="result-modal">
            <div class="modal-content">
              <h2 v-if="winner === 'draw'">🤝 Match Nul !</h2>
              <h2 v-else-if="winner === P1">🏆 Victoire !</h2>
              <h2 v-else>🤖 L'IA a gagné</h2>
              <div class="modal-actions">
                <button @click="startGame" class="etml-btn">Rejouer</button>
                <button @click="backToSetup" class="etml-btn secondary">Menu Principal</button>
              </div>
            </div>
          </div>
        </transition>
      </div>
    </transition>
    <RouterLink to="/games" class="back-link">Retour au menu</RouterLink>
  </div>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap');

.c4-container {
  text-align: center;
  max-width: 800px;
  margin: 0 auto;
  font-family: 'Poppins', sans-serif;
  padding: 20px;
  color: #334155;
}

.brand-header {
  margin-bottom: 30px;
}
.logo-text {
  font-size: 2.5rem;
  font-weight: 800;
  color: #0f172a;
  letter-spacing: -1px;
}
.subtitle {
  color: #3b82f6;
  font-weight: 600;
  font-size: 1.2rem;
  display: block;
  letter-spacing: 2px;
}

.card {
  background: white;
  padding: 40px;
  border-radius: 24px;
  box-shadow: 0 20px 40px -5px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
}

/* Setup Screen */
.setup-card h1 {
  font-size: 1.8rem;
  margin-bottom: 10px;
  color: #1e293b;
}
.intro-text {
  color: #64748b;
  margin-bottom: 30px;
  font-size: 1.1rem;
}
.intro-text strong {
  color: #3b82f6;
}

.label-diff {
  font-weight: 600;
  margin-bottom: 15px;
  color: #334155;
  display: block;
  text-align: left;
}

.diff-select {
  display: flex;
  gap: 15px;
  margin-bottom: 30px;
}
.diff-select button {
  flex: 1;
  padding: 15px;
  border: 2px solid #e2e8f0;
  background: #f8fafc;
  cursor: pointer;
  border-radius: 16px;
  font-weight: 600;
  font-family: inherit;
  color: #64748b;
  transition: all 0.2s;
}
.diff-select button:hover {
  border-color: #3b82f6;
  color: #3b82f6;
  background: #eff6ff;
}
.diff-select button.active {
  background: #3b82f6;
  color: white;
  border-color: #3b82f6;
  box-shadow: 0 10px 20px -5px rgba(59, 130, 246, 0.4);
  transform: translateY(-2px);
}

.etml-btn {
  width: 100%;
  padding: 16px;
  background: #0f172a;
  color: white;
  border: none;
  border-radius: 16px;
  font-weight: 700;
  cursor: pointer;
  font-size: 1.1rem;
  font-family: inherit;
  transition: all 0.2s;
  box-shadow: 0 10px 20px -5px rgba(15, 23, 42, 0.3);
}
.etml-btn:hover {
  background: #1e293b;
  transform: translateY(-2px);
  box-shadow: 0 15px 25px -5px rgba(15, 23, 42, 0.4);
}
.etml-btn:active {
  transform: translateY(0);
}

.etml-btn.secondary {
  background: transparent;
  color: #64748b;
  border: 2px solid #e2e8f0;
  box-shadow: none;
  margin-top: 20px;
}
.etml-btn.secondary:hover {
  border-color: #cbd5e1;
  color: #334155;
  background: #f1f5f9;
}

/* HUD */
.game-hud {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 30px;
  margin-bottom: 30px;
  background: white;
  padding: 15px 30px;
  border-radius: 50px;
  box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.1);
}
.player-tag {
  display: flex;
  align-items: center;
  gap: 10px;
  font-weight: 600;
  color: #94a3b8;
  transition: all 0.3s;
}
.player-tag.active {
  color: #0f172a;
  transform: scale(1.05);
}
.player-tag .dot {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #cbd5e1;
}
.player-tag.p1.active .dot {
  background: #ef4444;
  box-shadow: 0 0 10px rgba(239, 68, 68, 0.5);
}
.player-tag.p2.active .dot {
  background: #eab308;
  box-shadow: 0 0 10px rgba(234, 179, 8, 0.5);
}

.game-status {
  font-weight: 800;
  color: #cbd5e1;
  font-size: 1.2rem;
}

/* BOARD */
.board-container {
  position: relative;
  display: inline-block;
  padding: 20px;
  background: white;
  border-radius: 30px;
  box-shadow: 0 20px 40px -5px rgba(0, 0, 0, 0.1);
}

.click-layer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  z-index: 100;
}
.col-trigger {
  flex: 1;
  cursor: pointer;
  border-radius: 100px;
  transition: background 0.2s;
}
.col-trigger:hover {
  background: rgba(59, 130, 246, 0.1);
}

.board-visual {
  background-color: #3b82f6;
  padding: 15px;
  border-radius: 20px;
  display: inline-block;
  position: relative;
  box-shadow: inset 0 0 20px rgba(0, 0, 0, 0.2);
}
.row {
  display: flex;
}
.cell {
  width: 60px;
  height: 60px;
  margin: 6px;
  position: relative;
  background: #1e40af;
  border-radius: 50%;
  box-shadow: inset 2px 2px 5px rgba(0, 0, 0, 0.3);
}
.hole-mask {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  z-index: 10;
  pointer-events: none;
  box-shadow: inset 3px 3px 8px rgba(0, 0, 0, 0.4);
}

.piece {
  position: absolute;
  inset: 4px;
  border-radius: 50%;
  z-index: 1;
  box-shadow:
    inset -2px -2px 5px rgba(0, 0, 0, 0.2),
    2px 2px 5px rgba(255, 255, 255, 0.3);
}
.piece.is-p1 {
  background: radial-gradient(circle at 30% 30%, #f87171, #dc2626);
}
.piece.is-p2 {
  background: radial-gradient(circle at 30% 30%, #fde047, #ca8a04);
}
.piece.is-winner {
  border: 4px solid white;
  z-index: 20;
  animation: flash 1s infinite;
}

.drop-enter-active {
  animation: drop-anim 0.5s cubic-bezier(0.5, 0, 0.5, 1.2);
}
@keyframes drop-anim {
  0% {
    transform: translateY(-400px);
  }
  100% {
    transform: translateY(0);
  }
}
@keyframes flash {
  0%,
  100% {
    filter: brightness(1);
    transform: scale(1);
  }
  50% {
    filter: brightness(1.3);
    transform: scale(1.05);
  }
}

/* Modal */
.result-modal {
  position: absolute;
  inset: 0;
  background: rgba(15, 23, 42, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 200;
  backdrop-filter: blur(4px);
  border-radius: 30px;
  animation: fade-in 0.3s;
}
.modal-content {
  background: white;
  padding: 40px;
  border-radius: 24px;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  border: none;
  min-width: 300px;
  text-align: center;
  animation: slide-up 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}
.modal-content h2 {
  font-size: 2rem;
  margin-bottom: 25px;
  color: #1e293b;
}
.modal-actions {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.back-link {
  display: inline-block;
  margin-top: 40px;
  color: #94a3b8;
  text-decoration: none;
  font-weight: 600;
  transition: color 0.2s;
}
.back-link:hover {
  color: #3b82f6;
}

@keyframes fade-in {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes slide-up {
  from {
    transform: translateY(20px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}
</style>
