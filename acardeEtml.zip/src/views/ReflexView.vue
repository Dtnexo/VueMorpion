<script setup>
import { ref } from 'vue'

const state = ref('waiting') // waiting, ready, now, finished, too-early
const message = ref('Cliquez pour commencer')
const startTime = ref(0)
const reactionTime = ref(0)
let timer = null

const startTest = () => {
  state.value = 'ready'
  message.value = 'Attendez le VERT...'

  // Délai aléatoire entre 2 et 5 secondes
  const randomDelay = Math.floor(Math.random() * 3000) + 2000

  timer = setTimeout(() => {
    state.value = 'now'
    message.value = 'CLIQUEZ !'
    startTime.value = Date.now()
  }, randomDelay)
}

const handleClick = () => {
  if (state.value === 'waiting') {
    startTest()
  } else if (state.value === 'ready') {
    // Trop tôt
    clearTimeout(timer)
    state.value = 'too-early'
    message.value = 'Trop tôt ! Attendez le vert.'
  } else if (state.value === 'now') {
    // Succès
    const endTime = Date.now()
    reactionTime.value = endTime - startTime.value
    state.value = 'finished'
    message.value = `${reactionTime.value} ms`
  } else {
    // Reset si fini ou raté
    state.value = 'waiting'
    message.value = 'Cliquez pour réessayer'
  }
}
</script>

<template>
  <div class="reflex-container">
    <div class="card">
      <h1>Test de Réflexes</h1>
      <p class="subtitle">Cliquez quand l'écran devient VERT</p>

      <div class="reflex-box" :class="state" @mousedown="handleClick">
        <div class="content">
          <div class="icon" v-if="state === 'waiting'">⚡</div>
          <div class="icon" v-if="state === 'too-early'">⚠️</div>
          <div class="score" v-if="state === 'finished'">{{ reactionTime }} ms</div>
          <h2>{{ message }}</h2>
        </div>
      </div>

      <RouterLink to="/" class="back-link">Retour au menu</RouterLink>
    </div>
  </div>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap');

.reflex-container {
  width: 100%;
  max-width: 700px;
  margin: 0 auto;
  padding: 20px;
  font-family: 'Poppins', sans-serif;
  color: #334155;
}

.card {
  background: white;
  padding: 40px;
  border-radius: 24px;
  box-shadow: 0 20px 40px -5px rgba(0, 0, 0, 0.1);
  text-align: center;
}

h1 {
  color: #0f172a;
  font-weight: 800;
  font-size: 2.5rem;
  margin-bottom: 10px;
}

.subtitle {
  color: #64748b;
  margin-bottom: 30px;
  font-size: 1.1rem;
}

.reflex-box {
  height: 350px;
  background-color: #3b82f6; /* Blue default */
  color: white;
  border-radius: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  user-select: none;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 10px 20px -5px rgba(59, 130, 246, 0.4);
  margin: 30px 0;
  position: relative;
  overflow: hidden;
}

.reflex-box:hover {
  transform: translateY(-2px);
  box-shadow: 0 20px 25px -5px rgba(59, 130, 246, 0.5);
}

.reflex-box:active {
  transform: scale(0.98);
}

.reflex-box.waiting {
  background-color: #3b82f6;
}
.reflex-box.ready {
  background-color: #ef4444; /* Red */
  box-shadow: 0 10px 20px -5px rgba(239, 68, 68, 0.4);
  cursor: wait;
}
.reflex-box.now {
  background-color: #22c55e; /* Green */
  box-shadow: 0 10px 20px -5px rgba(34, 197, 94, 0.4);
}
.reflex-box.finished {
  background-color: #f8fafc;
  color: #0f172a;
  border: 4px solid #3b82f6;
  box-shadow: none;
}
.reflex-box.too-early {
  background-color: #f59e0b; /* Orange */
  box-shadow: 0 10px 20px -5px rgba(245, 158, 11, 0.4);
}

.content {
  pointer-events: none;
  z-index: 10;
}

.icon {
  font-size: 5rem;
  margin-bottom: 15px;
  animation: bounce 1s infinite;
}

.score {
  font-size: 6rem;
  font-weight: 800;
  color: #3b82f6;
  line-height: 1;
  margin-bottom: 10px;
}

h2 {
  font-size: 1.8rem;
  margin: 0;
  font-weight: 700;
}

.back-link {
  display: inline-block;
  margin-top: 20px;
  color: #94a3b8;
  text-decoration: none;
  font-weight: 600;
  transition: color 0.2s;
}
.back-link:hover {
  color: #3b82f6;
}

@keyframes bounce {
  0%,
  100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px);
  }
}
</style>
